import ml_collections

def get_testing():
    """Returns a minimal configuration for testing."""
    config = ml_collections.ConfigDict()
    config.patches = ml_collections.ConfigDict({'size': (16, 16)})
    config.hidden_size = 1
    config.transformer = ml_collections.ConfigDict()
    config.transformer.mlp_dim = 1
    config.transformer.num_heads = 1
    config.transformer.num_layers = 1
    config.transformer.attention_dropout_rate = 0.0
    config.transformer.dropout_rate = 0.1
    config.classifier = 'token'
    config.representation_size = None
    return config

def get_b16_config():
    """Returns the ViT-B/16 configuration."""
    config = ml_collections.ConfigDict()
    config.patches = ml_collections.ConfigDict({'size': (16, 16)})
    config.num_stages = 3
    config.split = 'non-overlap'
    config.slide_step = 12
    config.d_model = 256
#     config.patchsize = [(4,4),(4,4),(4,4),(8,8),(8,8),(8,8),(14,14),(14,14),(14,14),(16,16),(16,16),(16,16)]
    config.patchsize = [(4,4),(4,4),(8,8),(8,8),(14,14),(14,14),(16,16),(16,16)]
   # Setting `config.hidden_size = 768` is defining the size of the hidden layers in the model
   # configuration. In this case, it is setting the hidden size to 768 units. This parameter is
   # important in determining the capacity and complexity of the model. The hidden size affects the
   # number of parameters in the model and can impact its ability to learn and represent complex
   # patterns in the data.
    config.hidden_size = 768
    config.transformer = ml_collections.ConfigDict()
    config.transformer.mlp_dim = 3072
    config.transformer.num_heads = 12
    config.transformer.num_layers = 12
    config.transformer.attention_dropout_rate = 0.0
    config.transformer.dropout_rate = 0.1
    config.classifier = 'token'
    config.representation_size = None
    # other_config
    other_config = ml_collections.ConfigDict()
    other_config.hidden_size = 768*11 
    other_config.transformer = ml_collections.ConfigDict()
    other_config.transformer.mlp_dim = 768*11*4
    other_config.transformer.num_heads = 12
    other_config.transformer.attention_dropout_rate = 0.0
    other_config.transformer.dropout_rate = 0.1
    other_config.classifier = 'token'
    other_config.representation_size = None
    return config, other_config
def get_b16_config():
    """Returns the ViT-B/16 configuration."""
    config = ml_collections.ConfigDict()
    config.patches = ml_collections.ConfigDict({'size': (16, 16)})
    config.num_stages = 3
    config.split = 'non-overlap'
    config.slide_step = 12
    config.d_model = 256
#     config.patchsize = [(4,4),(4,4),(4,4),(8,8),(8,8),(8,8),(14,14),(14,14),(14,14),(16,16),(16,16),(16,16)]
    config.patchsize = [(4,4),(4,4),(8,8),(8,8),(14,14),(14,14),(16,16),(16,16)]
    config.hidden_size = 768
    config.transformer = ml_collections.ConfigDict()
    config.transformer.mlp_dim = 3072
    config.transformer.num_heads = 12
    config.transformer.num_layers = 12
    config.transformer.attention_dropout_rate = 0.0
    config.transformer.dropout_rate = 0.1
    config.classifier = 'token'
    config.representation_size = None
    return config
def get_b32_config():
    """Returns the ViT-B/32 configuration."""
    config = get_b16_config()
    config.patches.size = (32, 32)
    return config

def get_l16_config():
    """Returns the ViT-L/16 configuration."""
    config = ml_collections.ConfigDict()
    config.patches = ml_collections.ConfigDict({'size': (16, 16)})
    config.hidden_size = 1024
    config.transformer = ml_collections.ConfigDict()
  
    config.transformer.mlp_dim = 4096
    config.transformer.num_heads = 16
    config.transformer.num_layers = 24
    config.transformer.attention_dropout_rate = 0.0
    config.transformer.dropout_rate = 0.1
    config.classifier = 'token'
    config.representation_size = None
    return config

def get_l32_config():
    """Returns the ViT-L/32 configuration."""
    config = get_l16_config()
    config.patches.size = (32, 32)
    return config

def get_h14_config():
    """Returns the ViT-L/16 configuration."""
    config = ml_collections.ConfigDict()
    config.patches = ml_collections.ConfigDict({'size': (14, 14)})
    config.hidden_size = 1280
    config.transformer = ml_collections.ConfigDict()
    config.transformer.mlp_dim = 5120
    config.transformer.num_heads = 16
    config.transformer.num_layers = 32
    config.transformer.attention_dropout_rate = 0.0
    config.transformer.dropout_rate = 0.1
    config.classifier = 'token'
    config.representation_size = None
    return config