import logging
from PIL import Image
import os
import torch
from torchvision import transforms
from torch.utils.data import DataLoader, RandomSampler, DistributedSampler, SequentialSampler
from utils.autoaugment import AutoAugImageNetPolicy
from torchvision import datasets
import torchvision.transforms as transforms
logger = logging.getLogger(__name__)
# Class identify 
def get_loader(args):
    if args.local_rank not in [-1, 0]:
        torch.distributed.barrier()

    if args.dataset == 'ASLO':
        train_transform=transforms.Compose([transforms.Resize((600, 600), Image.BILINEAR),
                                    transforms.RandomCrop((224,224)),
    
                                    transforms.RandomHorizontalFlip(),
                                    transforms.ToTensor(),
                                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
        test_transform=transforms.Compose([transforms.Resize((600, 600), Image.BILINEAR),
                                    transforms.CenterCrop((224,224)),       
                                    transforms.ToTensor(),
                                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
        trainset = datasets.ImageFolder(root='ASLOPlankton/ASLO-Plankton/training',  transform=train_transform)
        testset = datasets.ImageFolder(root='ASLOPlankton/ASLO-Plankton/testing', transform = test_transform)

    if args.dataset == 'SHARK':
        train_transform=transforms.Compose([transforms.Resize((600, 600), Image.BILINEAR),
                                    transforms.RandomCrop((448,448)),
    
                                    transforms.RandomHorizontalFlip(),
                                    transforms.ToTensor(),
                                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
        test_transform=transforms.Compose([transforms.Resize((600, 600), Image.BILINEAR),
                                    transforms.CenterCrop((448,448)),       
                                    transforms.ToTensor(),
                                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
        trainset = datasets.ImageFolder(root='Shark/Shark_test',  transform=train_transform)
        testset = datasets.ImageFolder(root='Shark/Shark_test', transform = test_transform)
    if args.dataset == 'WILDFISH':
        train_transform=transforms.Compose([transforms.Resize((600, 600), Image.BILINEAR),
                                    transforms.RandomCrop((448,448)),
    
                                    transforms.RandomHorizontalFlip(),
                                    transforms.ToTensor(),
                                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
        test_transform=transforms.Compose([transforms.Resize((600, 600), Image.BILINEAR),
                                    transforms.CenterCrop((448,448)),       
                                    transforms.ToTensor(),
                                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
        trainset = datasets.ImageFolder(root='fish______3/train',  transform=train_transform)
        testset = datasets.ImageFolder(root='fish______3/test', transform = test_transform)
      

    
    train_sampler = RandomSampler(trainset) if args.local_rank == -1 else DistributedSampler(trainset)
#     test_sampler = SequentialSampler(testset) if args.local_rank == -1 else DistributedSampler(testset)
    test_sampler = RandomSampler(testset) if args.local_rank == -1 else DistributedSampler(testset)
    train_loader = DataLoader(trainset,
#                               sampler=train_sampler,
                              sampler=train_sampler,
                              batch_size=args.train_batch_size,
                              num_workers=0,
                              drop_last=True,
                              pin_memory=False)
    test_loader = DataLoader(testset,
                             sampler=test_sampler,
                             batch_size=args.eval_batch_size,
                             num_workers=0,
                             pin_memory=False) if testset is not None else None

    return train_loader, test_loader
